# Pixel Pro — Netlify Deploy Guide 🚀

Your app now has a **secure backend**. The Gemini (Google Cloud) API key lives
on Netlify's server, hidden from the public. Follow these steps.

---

## What's in this folder

```
pixelpro/
├── index.html                     ← Pixel Pro front-end (NO key inside)
├── netlify.toml                   ← tells Netlify about the function
├── package.json                   ← marks it as a Node project
├── DEPLOY-GUIDE.md                ← this file
└── netlify/
    └── functions/
        └── ask.js                 ← backend — key lives here (via env var)
```

The key is **never** written in any file. It is read from an environment
variable called `GEMINI_KEY` that you set in the Netlify dashboard.

---

## ⚠️ FIRST: regenerate your key

You pasted your old key in chat, so treat it as public. Make a fresh one:

1. Go to → https://console.cloud.google.com/apis/credentials
2. Select your project → delete the old key
3. **+ CREATE CREDENTIALS → API key** → copy the new `AIza...` key
4. Also enable the API: https://console.cloud.google.com/apis/library
   → search **"Generative Language API"** → **ENABLE**

---

## Deploy — the drag-and-drop way (easiest)

Netlify Drop does NOT run functions, so use the dashboard method below.

### Step 1 — Create the site from this folder
1. Zip this whole `pixelpro` folder (or push it to GitHub).
2. **GitHub way (recommended):**
   - Put the folder in a GitHub repo.
   - Netlify → **Add new site → Import an existing project** → pick the repo.
   - Netlify auto-detects `netlify.toml` and the function. Click **Deploy**.
3. **CLI way (no GitHub):**
   - Install once: `npm install -g netlify-cli`
   - In the folder: `netlify deploy --prod`

### Step 2 — Add your secret key
1. Netlify dashboard → your site → **Site configuration**
2. → **Environment variables** → **Add a variable**
3. Key: `GEMINI_KEY`
4. Value: your new `AIza...` key
5. **Save**

### Step 3 — Redeploy so the key takes effect
- Netlify → **Deploys** → **Trigger deploy → Deploy site**

### Step 4 — Test
- Open your site. Ask: *"Who won the FIFA 2026 final?"*
- It should answer with **live web sources** listed underneath. ✅

---

## How it works

```
Browser (index.html)  →  /.netlify/functions/ask  →  Gemini API
   public, no key           key hidden here            Google
```

- Gemini 2.5 Flash is called **with Google Search grounding**, so the AI
  decides on its own when to search the web — like ChatGPT.
- If the function is ever unavailable (e.g. you open index.html locally, or
  the daily free quota runs out), Pixel Pro **automatically falls back** to the
  keyless Pollinations brain so it never fully breaks.

---

## Free-tier limits (Gemini 2.5 Flash)

- ~1,500 requests/day, ~15/minute — plenty for demos and early clients.
- Free-tier prompts may be used by Google to improve their models.
- If you exceed the free quota, the app auto-falls-back to keyless mode.

---

## Troubleshooting

| Problem | Fix |
|---|---|
| "Server key missing" | You didn't set `GEMINI_KEY`, or didn't redeploy after adding it. |
| 403 "API not enabled" | Enable **Generative Language API** in Google Cloud, wait 1–2 min. |
| Function 404 | You used Netlify **Drop**. Use GitHub import or `netlify deploy` instead. |
| Answers but no sources | Normal — not every question needs a web search. |

---

Powered by **NeelOutLoud Website Builders** 😎

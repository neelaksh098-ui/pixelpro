// ================================================================
//  Pixel Pro — backend function  (netlify/functions/ask.js)
//  Holds your Google Cloud (Gemini) API key SECRETLY on Netlify's
//  server, and calls the Generative Language API with live
//  Google Search grounding so the AI can search the web itself.
//
//  The key is read from the GEMINI_KEY environment variable.
//  It NEVER appears in the browser. That is the whole point.
// ================================================================

const MODEL = "gemini-2.5-flash"; // free-tier workhorse (1,500 req/day)

exports.handler = async (event) => {
  const CORS = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Content-Type": "application/json",
  };

  // Browser pre-flight
  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers: CORS, body: "" };
  if (event.httpMethod !== "POST")
    return { statusCode: 405, headers: CORS, body: JSON.stringify({ error: "Use POST." }) };

  const KEY = process.env.GEMINI_KEY;
  if (!KEY)
    return {
      statusCode: 500,
      headers: CORS,
      body: JSON.stringify({ error: "Server key missing. Set GEMINI_KEY in Netlify → Environment variables." }),
    };

  // Parse incoming messages
  let payload;
  try {
    payload = JSON.parse(event.body || "{}");
  } catch (e) {
    return { statusCode: 400, headers: CORS, body: JSON.stringify({ error: "Bad JSON." }) };
  }
  const messages = Array.isArray(payload.messages) ? payload.messages : [];
  const useSearch = payload.search !== false; // web search ON by default

  // Convert OpenAI-style messages -> Gemini format
  const systemMsg = messages.find((m) => m.role === "system");
  const contents = messages
    .filter((m) => m.role !== "system")
    .map((m) => ({
      role: m.role === "assistant" ? "model" : "user",
      parts: [{ text: String(m.content || "") }],
    }));

  if (!contents.length)
    return { statusCode: 400, headers: CORS, body: JSON.stringify({ error: "No message." }) };

  const body = {
    contents,
    generationConfig: { temperature: 0.7, maxOutputTokens: 1400 },
  };
  if (systemMsg) body.systemInstruction = { parts: [{ text: String(systemMsg.content) }] };
  // Let Gemini decide when to search Google and ground its answer:
  if (useSearch) body.tools = [{ google_search: {} }];

  const url =
    "https://generativelanguage.googleapis.com/v1beta/models/" +
    MODEL +
    ":generateContent?key=" +
    encodeURIComponent(KEY);

  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 45000);
    const r = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      signal: ctrl.signal,
    }).finally(() => clearTimeout(timer));

    const d = await r.json();

    if (!r.ok) {
      const msg = (d && d.error && d.error.message) || "Gemini request failed.";
      return { statusCode: r.status, headers: CORS, body: JSON.stringify({ error: msg }) };
    }

    const cand = d.candidates && d.candidates[0];
    const text =
      cand && cand.content && cand.content.parts
        ? cand.content.parts.map((p) => p.text || "").join("").trim()
        : "";

    // Pull the live web sources Gemini used (grounding metadata)
    let sources = [];
    const gm = cand && cand.groundingMetadata;
    if (gm && Array.isArray(gm.groundingChunks)) {
      sources = gm.groundingChunks
        .filter((c) => c.web && c.web.uri)
        .map((c) => ({ title: c.web.title || c.web.uri, link: c.web.uri }))
        .slice(0, 4);
    }

    if (!text)
      return { statusCode: 502, headers: CORS, body: JSON.stringify({ error: "Empty reply from model." }) };

    return { statusCode: 200, headers: CORS, body: JSON.stringify({ text, sources }) };
  } catch (e) {
    return {
      statusCode: 502,
      headers: CORS,
      body: JSON.stringify({ error: "Upstream error: " + (e && e.message ? e.message : "unknown") }),
    };
  }
};
